def select_even_nums(arr)
    #arr.select { |ele| ele.even? }
    arr.select(&:even?)
end

def reject_puppies(arr)
    arr.reject { |ele| ele["age"] <= 2} #ask if there's a usable method
end

def count_positive_subarrays(arr)
    arr.count { |val| val.sum > 0 }
end

# debugger after
def aba_translate(word)
    vowels = 'aeiou'
    re_word = ''
    word.each_char.with_index do |char, idx|
        #if vowels.include?(char)
        #   word.insert(idx + 1, char + 'b')
        #end
        if vowels.include?(char)
            re_word << char + 'b' + char
        else
            re_word << char
        end
    end
    re_word
end

def aba_array(words)
    #words.map(&:aba_translate)
    words.map {|word| aba_translate(word)}
end