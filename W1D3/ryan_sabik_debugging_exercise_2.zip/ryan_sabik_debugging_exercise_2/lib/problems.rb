# Run `bundle exec rspec` and satisy the specs.
# You should implement your methods in this file.
# Feel free to use the debugger when you get stuck.

require "byebug"

def is_prime?(num)
    return false if num < 2
    (2..Math.sqrt(num)).none? { |i| num % i == 0 }
end
#p is_prime?(2)
#p is_prime?(4)
#p is_prime?(11)
def largest_prime_factor(num)
    return num if is_prime?(num)
    #debugger
    (2...num).inject { |accu, val| num % val == 0 && is_prime?(val) ? val : accu }
end

def unique_chars?(string)
    arr = []
    string.each_char do |char|
        if arr.include?(char)
            return false
        else
            arr << char
        end
        #arr.include?(char) ? false : arr << char #can't explicitly return in ternary statement
    end
    true
end

def dupe_indices(arr)
    re_hash = {}

    counter_hash = {}
    arr.each_with_index do |ele, idx|
        if counter_hash.has_key?(ele)
            counter_hash[ele] << idx
        else
            counter_hash[ele] = [idx]
        end
    end

    counter_hash.each_key do |key|
        if counter_hash[key].length > 1
            re_hash[key] = counter_hash[key] #pipe every idx into re_hash
        end
    end
    
    re_hash
end

def ana_array(arr1, arr2)
    counter_hash_1 = Hash.new(0)
    counter_hash_2 = Hash.new(0)

    arr1.each {|val| counter_hash_1[val] += 1}
    arr2.each {|val| counter_hash_2[val] += 1}

    counter_hash_1 == counter_hash_2
end