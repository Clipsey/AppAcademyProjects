class Player

    def initialize(name)
        @name = name
    end

    def guess
        puts "Enter char"
        return gets.chomp
    end

    def invalid_guess
        # hey [@name], you gave invalid guess, try again
        puts "Hey, #{@name}, you gave an invalid guess, try again."
    end
end