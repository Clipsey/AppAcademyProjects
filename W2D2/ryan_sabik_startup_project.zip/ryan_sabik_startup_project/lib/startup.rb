require "employee"

class Startup
    attr_reader :name, :funding, :salaries, :employees

    def initialize(name, funding, salaries)
        @name = name
        @funding = funding
        @salaries = salaries
        @employees = []
    end

    def valid_title?(title)
        @salaries.has_key?(title)
    end

    def >(startup)
        self.funding > startup.funding
    end

    def hire(name, title)
        unless valid_title?(title)
            raise "invalid title"
        else
            @employees << Employee.new(name, title)
        end
    end

    def size
        @employees.size
    end

    def pay_employee(employee)
        salary = @salaries[employee.title]
        if @funding > salary
            employee.pay(salary)
            @funding -= salary
        else
            raise "not enough funding"
        end
    end

    def payday
        @employees.each { |employee| pay_employee(employee) }
    end

    def average_salary
        sum = @employees.sum { |employee| @salaries[employee.title] }
        sum / @employees.size.to_f
    end

    def close
        @employees = []
        @funding = 0
    end

    def acquire(startup)
        @funding += startup.funding
        startup.salaries.each do |job, salary|
            @salaries[job] = salary unless @salaries.has_key?(job)
        end
        @employees.push(*startup.employees)
        startup.close
    end
end
