class Room
    attr_reader :capacity, :occupants

    def initialize(capacity)
        @capacity = capacity
        @occupants = []
    end

    def full?
        @occupants.size >= @capacity
    end

    def available_space
        @capacity - @occupants.size
    end

    def add_occupant(name)
        unless self.full?
            @occupants << name
            return true
        else 
            return false
        end
    end

end
