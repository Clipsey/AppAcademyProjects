require_relative "board.rb"
require_relative "card.rb"

class Game

    def initialize
        @board = Board.new
        @board.populate
    end

    def play
        until @board.won?
             
            #continue playing the game
            
            @board.render
            
            guess_pos1 = user_guess
            until make_guess(guess_pos1)
                @board.render
                guess_pos1 = user_guess
            end

            @board.render
            
            guess_pos2 = user_guess
            until make_guess(guess_pos2)
                @board.render
                guess_pos2 = user_guess
            end
            
            
            @board.render
            check_guesses(guess_pos1, guess_pos2)
            #check if both guesses are a pair/match
            #make guess on guess_pos

            #puts "Enter your guess"
        end
        puts "you won!"
    end

    def user_guess
        puts "Enter your guess (e.g. 2,3)"
        gets.chomp
    end

    def make_guess(guess_pos)
        # p 'Is the face showing:'
        # p @board[guess_pos].face_showing
        if !@board[guess_pos].face_showing
            @board.reveal(guess_pos)
            true
        else 
            p "That has already been guessed."
            false
        end
    end

    def check_guesses(guess_1, guess_2) # hide cards if invalid guess or cards aren't a pair.
        #check to see if either guess is already face up.
        #if already face up, then that guess does not get hidden
        


        if @board.reveal(guess_1) != @board.reveal(guess_2) || guess_1 == guess_2
            @board.hide_card(guess_1)
            @board.hide_card(guess_2)
            p "Try again, it's not a match."
        else
            p "It's a match!"
        end
    end
end