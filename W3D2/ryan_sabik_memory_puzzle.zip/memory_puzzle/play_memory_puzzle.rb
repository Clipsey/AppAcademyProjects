require_relative "game.rb"
require_relative "board.rb"
require_relative "card.rb"

new_game = Game.new
new_game.play