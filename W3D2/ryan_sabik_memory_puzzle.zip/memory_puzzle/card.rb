class Card
    attr_reader :face_value, :face_showing
    def initialize(str)
        @face_value = str #should contain one face value
        @face_showing = false
    end

    def hide
        @face_showing = false
    end

    def reveal
        @face_showing = true
    end

    def ==(card)
        if card == nil
            self.face_value == nil
        else
            self.face_value == card.face_value
        end
    end
end
