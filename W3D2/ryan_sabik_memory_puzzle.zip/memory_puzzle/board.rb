require_relative 'card.rb'
class Board
    def initialize
        @grid = Array.new(4) {Array.new(4)}
        @values = ('a'..'h').to_a
    end

    def populated?
        @grid.all? do |ele|
            ele.none? {|inner_ele| nil == inner_ele}
        end
    end

    def populate
        until populated?
            #4 2.times loops
            card_value = @values.sample
            @values.delete(card_value)
            position = [0,0]
            2.times do
                until nil == self[position]
                    position = [rand(4), rand(4)]
                end
                self[position] = Card.new(card_value)
            end
        end
    end

    def render
        puts "  0 1 2 3"
        @grid.each_with_index do |row, idx|
            row_str = idx.to_s
            row.each do |ele|
                if ele == nil || !ele.face_showing
                    row_str << '  '
                else
                    row_str << ' ' + ele.face_value 
                end
            end
            puts row_str
            # p idx.to_s + row.join(' ')
        end
    end

    def won?
        @grid.all? do |row|
            row.all? { |ele|  ele != nil ? ele.face_showing : false}
        end
    end

    def reveal(pos)
        self[pos].reveal
        self[pos].face_value
    end

    def hide_card(pos)
        self[pos].hide
    end

    def [](pos)
        idx_1 = pos[0].to_i
        idx_2 = pos[-1].to_i
        @grid[idx_1][idx_2]
    end

    def []=(pos, val)
        idx_1 = pos[0].to_i
        idx_2 = pos[-1].to_i
        @grid[idx_1][idx_2] = val
    end
end

# board = Board.new
# board.populate
# board.render