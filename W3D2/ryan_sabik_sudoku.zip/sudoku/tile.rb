require 'colorized_string'

sudoku_boards = Array[
    File.read("./puzzles/sudoku1.txt").split(' '), 
    File.read("./puzzles/sudoku2.txt").split(' '), 
    File.read("./puzzles/sudoku3.txt").split(' ')
]

#sudoku_boards = [
    #[
    #   [row1]
    #   [row2]
    #   [row3]
    #   ...
    #   [row_n]
    #]

#]

#board_selector => pick what board you want to run

sudoku_boards.each do |board|
    board.map! do |row|
        row.split('')
    end
end

p sudoku_boards[0]