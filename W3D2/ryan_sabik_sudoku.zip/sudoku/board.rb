require 'colorized_string'
require_relative "tile.rb"

#to check rows, we can iterate through each element in each row to see if any
#are zero and that all are unique.

#to check columns, we can do the same thing after using array#transpose

#Array#uniq => Array#length to make sure size is still 9.