require 'colorized_string'
require_relative "board.rb"
require_relative "tile.rb"