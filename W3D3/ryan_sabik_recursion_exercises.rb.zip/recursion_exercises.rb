require 'byebug'
# def range(start, fin)
#     return fin - 1 if start == fin - 1
#     ([start] << range(start + 1, fin)).flatten
# end

def range(start, fin)
    (start...fin).select {|ele| ele } 
end

# p range(1, 5) #=> [1,2,3,4]
# p range(10, 15) #=> [10, 11, 12, 13, 14]
# p range(21, 25) #=> [21, 22, 23, 24]
# p range(0, 10) #=> [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

def exp(base, power)
    return 1 if power == 0

    base * exp(base, power - 1)
end

def exp2(base, power)
    return 1 if power == 0
    return base if power == 1
    # return base * base if power == 2
    if power.even?
        exp2(base, power / 2) * exp2(base, power / 2)
    else
        (base * exp2(base, (power)/2)) * exp2(base, (power)/2)
    end
end

# p exp2(10, 0) #=> 1
# p exp2(2, 3) #=> 8
# p exp2(3, 4) #=> 81
# p exp2(4, 8) #=> 65536

def deep_dup(arr)
    return [] if arr.length == 0
    return arr if arr.length == 1
    new_arr = []
    arr.each do |ele|
        if ele.is_a? Array
            new_arr << deep_dup(ele)
        else
            new_arr << ele
        end
    end
    new_arr
end

# p deep_dup([])
# p deep_dup([1,2,3,4,5])
# p deep_dup([1,2,3,[4,[5]]])

# array1 = [1,2,3,[4,[5]]]
# array2 = array1.dup

# p array2

# array1[3] << 5

# p array1
# p array2

# array3 = deep_dup(array1)

# array1[3] << 6

# p array1
# p array2
# p array3

def fibonacci(n)
    return [0,1] if n <= 1
    result = fibonacci(n-1)
    result << result[-1] + result[-2]
    result
end

def fib(n)
    result = [0,1]
    (n-1).times do
        result << result[-2] + result[-1]
    end
    result
end

def bsearch(array, target)
    length = array.length 
    return array[0] if length <= 1
    mid = length/2
    if array[mid] > target
        array = array.slice(0, mid)
        bsearch(array, target)
    elsif array[mid] < target
        array = array.slice(mid + 1, length)
        bsearch(array, target)
    else
        return array[mid]
    end
end

# p fibonacci(5)
# p fibonacci(10)
# p fibonacci(11)

# p fib(5)
# p fib(10)
# p fib(11)

#p bsearch([0, 3, 5, 8, 15, 33], 3)
#p bsearch([0, 2, 3, 5, 8, 11, 15, 33], 11)


def merge_sort(array)
    length = array.length 
    return array if array.length <= 1
    mid = length/2
    left = array.slice(0, mid)
    right = array.slice(mid, length)
    left_sorted = merge_sort(left)
    right_sorted = merge_sort(right)
    stitch(left_sorted, right_sorted)
end

def stitch(left, right)
    result = []
    while !left.empty? && !right.empty?
        if left[0] < right[0]
            result << left.shift
        else
            result << right.shift
        end
    end
    while !left.empty?
        result << left.shift
    end
    while !right.empty?
        result << right.shift
    end
    result
end

# array = (1..22).to_a.shuffle
# p array
# p merge_sort(array)

class Array
    def subsets
        # return self if self.length <= 1
        # result = self
        # self.length.times do |i|
        #     result += self.slice(0...i).subsets + self.slice(i+1..-1).subsets
        # end
        # result
        # return self if self.length <= 1
        # debugger
        return [[]] if self.length == 0
        smaller_result = self.slice(0, self.length-1).subsets
        bigger_result = smaller_result.clone
        smaller_result.each do |val|
            tmp_val = val.clone
            tmp_val << self[-1]
            bigger_result << tmp_val
        end
        bigger_result
        #[[], [1],  [2], [1, 2]]
        #[[3], [1, 3]]
        #assume for [1, 2, 3], m2 subsets of array [1, 2] => [[], [1], [2], [1,2]] === [[], [1], [2], [1,2], [3], [1, 3], [2, 3], [1, 2, 3]]
        #each of m2, shovel into m2 => m2[counter] << 3
    end

    def perms
        #self == [1, 2, 3]
        #[1, 2]
        #[2, 1]

        #smaller_arrays
        #smaller_perms[smaller_arrays]
        #last excluded created smaller_arrays
        #bigger_array_size = smaller_array_size + one

        #i == counter into where we put the new element

        #0 to bigger_array_size -> 0 to smaller_array_size + one -> 0 to smaller_perms[0]_size plus 1


        #smaller_array size + 1
        #index goes from 0 to smaller_array size + 1
        #smaller_perms holds smaller_arrays
        #smaller_perms[0].length + 1

        #[1, 2, x]
        #[2, 1, x]

        #[x, 1, 2]
        #[x, 2, 1]

        #[1, x, 2]
        #[2, x, 1]
        #debugger
        return [self] if self.length <= 1
        smaller_arrays = self.slice(0, self.length - 1)
        smaller_perms = smaller_arrays.perms # => [[1, 2], [2, 1]] | self[self.length - 1] == 3
        last = self[self.length - 1]
        bigger_perms = []
        (smaller_perms[0].length + 1).times do |i|
            smaller_perms.each_with_index do |array, j|
                #new array of size ele + 1
                #shovel in ele at i
                #new_array = array.slice(0, i) + last + array.slice(i, end)
                # new_array = smaller_perms[j].insert(i, last)
                new_array = array.clone.insert(i, last)
                bigger_perms << new_array
            end
        end
        bigger_perms
    end
end

# p [1,2,3,4].subsets # => [[], [1], [2], [1, 2]]#, [3], [1, 3], [2, 3], [1, 2, 3]]


# #[]
# #[1]
# #[2]
# #[1, 2]
# #[3]
# #[1, 3]
# #[2, 3]
# #[1, 2, 3]

# p [1, 2].subsets #=> [[], [1], [2], [1, 2]]

# p [1, 2, 3, 4].perms # => [[1, 2, 3], [1, 3, 2],
#                         #     [2, 1, 3], [2, 3, 1],
#                         #     [3, 1, 2], [3, 2, 1]]


def greedy_make_change(value, coins)
    #Consider the case of greedy_make_change(24, [10,7,1]). Because it takes as 
    #many 10 pieces as possible, greedy_make_change misses the correct answer 
    #of [10,7,7] (try it in pry).

    #10, 10, 1, 1, 1, 1
    #if coins[0] < value
    # coin_array = []
    # sum = 0
    # while sum < value
    #     if sum + coins[0] <= value
    #         sum += coins[0]
    #         coin_array << coins[0]
    #     else
    #         #greedy_make_change(value, coins[1..-1])#coins.shift
    #     end
    # end

    return [value] if value == 0
    return [value] if coins.empty?

    coin_array = []
    # sum = 0
    while value > 0
        if value - coins[0] > 0
            value -= coins[0]
            coin_array << coins[0]
        else
            break
        end
    end
    coin_array += greedy_make_change(value, coins[1..-1])

    
    #First, write a 'greedy' version called greedy_make_change:

    #Take as many of the biggest coin as possible and add them to your result.
    #Add to the result by recursively calling your method on the remaining amount, leaving out the biggest coin, until the remainder is zero.
    
    #value - 
    #coins one value less'

    #coins[0] if it does not go any further divide -> then call greedy(value, coins - first element)
    #else greedy(value - coins[0], coins)
        #shoved into array?

    #keeping track of coins array?

    ##coin we are using is 10
    #[10] += greedy_make_change(14, coins)

end


#p greedy_make_change(24, [10, 7, 1])

def make_better_change(value, coins)
    # return [value] if value == 0
    # return [value] if coins.empty?

    # coin_array = []
    # # sum = 0
    # while value > 0
    #     if value - coins[0] > 0
    #         value -= coins[0]
    #         coin_array << coins[0]
    #     else
    #         break
    #     end
    # end
    # coin_array += make_better_change(value, coins[1..-1])

    #for each stack
    #pass in value and coins -> removing the largest element from the value -> call greedy without that coin and less of the value
    #remove the second largest from the value, and remove that coin from the next greedy
    #makegreedy(value - coins[0], coins[1..-1]) 
    #makegreedy(value - coins[1], coins[2..-1])
    #makegreedy(value - coins[2], coins[3..-1])

    #for every coin, recurse makegreedy(value - that coin, coins - that coin)
    #Consider the case of greedy_make_change(24, [10,7,1]). Because it takes as 
    #many 10 pieces as possible, greedy_make_change misses the correct answer 
    #of [10,7,7] (try it in pry).

    #return coin[0] if 

    #val == 14
    #coins == [10, 7, 1]
    coins.each_with_index do |coin, coin_index|
        make_better_change(value - coin, coins)
        make_better_change(value - coin, coins[coin_index+1..-1])
    end

    #24, [10, 7, 1]
    #make_better_change(14, [10, 7, 1])
        #mbc(4, [10, 7, 1])
        #mbc(4, [7, 1])
        #mbc(7, [10, 7, 1])
        #mbc(7, [1])
        #mbc(13, [1])
        #mbc(13, [])
    #make_better_change(14, [7, 1])
        #mbc(7, [1])
        #mbc(13, [])
    #mbc(17, [7, 1])
        #mbc(10, [7, 1])
            #mbc(3, [7, 1])
        #mbc(10, [1])
    #make_better_change(17, [1])
    #make_better_change(23, [])


end