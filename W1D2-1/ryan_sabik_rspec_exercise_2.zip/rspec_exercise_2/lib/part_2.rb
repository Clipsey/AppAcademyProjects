
def palindrome?(string)
    string_end_counter = string.length - 1
    (0..string.length / 2).all? { |i| string[i] == string[string_end_counter - i] } 
end

def substrings(string)
    #nested loops
    #outer loop == starting character
    #inner loop == end character
    #initialize empty array
    #string[i..j]
    subs = []
    (0..string.length-1).each do |i|
        (i..string.length-1).each do |j|
            subs << string[i..j]
        end
    end
    subs
end

def palindrome_substrings(string)
    subs = substrings(string)
    subs.select { |word| palindrome?(word) && word.length > 1 }
end
