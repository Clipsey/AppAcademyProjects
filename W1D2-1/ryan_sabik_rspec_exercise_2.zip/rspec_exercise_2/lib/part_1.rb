
def partition(array, num)
    less_array = []
    greater_array = []

    array.each do |ele|
        if ele < num
            less_array << ele
        else
            greater_array << ele
        end
    end

    [less_array, greater_array]
end


def merge(hash_1, hash_2)
    #initialize hash, add key-value pairs from hash 2
    #after input from hash 2, iterate through hash 1
        # if new hash doesn't have key in hash 1, then we add key-value pair
        # if it does, then don't add to hash 1
    #return new hash
    new_hash = Hash.new(0)
    hash_2.each {|key, value| new_hash[key] = value}
    hash_1.each do |key, value|
        unless new_hash.has_key?(key)
            new_hash[key] = value
        end
    end
    return new_hash
end

def censor(sentence, array)
    sentence_array = sentence.split(" ")

    sentence_array.map do |word|
        if array.include?(word.downcase)
            word.each_char.with_index do |char, idx|
                if "aeiouAEIOU".include?(char)
                    word[idx] = "*"
                end
            end
        end
        
        word
    end

    sentence_array.join(" ")
end

def power_of_two?(num)
    #iterate through powers of 2 (using index as the power)
    #return true if equal to num
    #return false otherwise
    (0..num).each {|i| return true if 2**i == num}
    false
end

