def hipsterfy(word)
    #iterate through word backwards
    #first vowel found, skip
    #every other character, concatenate to other variable
    vowels = "aeiou"
    first_vowel = false
    new_word = ""
    (word.length-1).downto(0) do |i|
        if vowels.include?(word[i]) && first_vowel == false
            first_vowel = true
        else
            new_word = word[i] + new_word
        end
    end
    new_word
end

def vowel_counts(string)
    vowel_amounts = Hash.new(0)
    vowels = "aeiouAEIOU"

    string.each_char { |char| vowel_amounts[char.downcase] += 1 if vowels.include?(char) }

    vowel_amounts
end

def caesar_cipher(message, n)
    #find index of old character and index of new character in alphabet
    #iterate through each char of the string
    #for each char, find index, add 'n' to index plus mod 26, add new char to new string [x]
    #new char represents char of index + n in alphabet
    #temp var of alphabet
    #empty string [x]

    alphabet = "abcdefghijklmnopqrstuvwxyz"
    return_string = ""
    message.each_char do |char|
        if alphabet.include?(char)
            old_index = alphabet.index(char)
            new_index = (old_index + n) % 26
            return_string += alphabet[new_index]
        else
            return_string += char
        end
    end
    return_string
end