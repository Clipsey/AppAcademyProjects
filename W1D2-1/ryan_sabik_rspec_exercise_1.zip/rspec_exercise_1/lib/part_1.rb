

def average(num_1, num_2)
 (num_1 + num_2) / 2.0
end

def average_array(arr)
    arr.sum / arr.length.to_f
end

def repeat(string, num)
    string * num
end

def yell(string)
    string.upcase + "!"
end

def alternating_case(string)
    sentence_array = string.split(" ")
    sentence_array.each_with_index { |word, idx| idx.odd? ? sentence_array[idx] = word.downcase : sentence_array[idx] = word.upcase }
    sentence_array.join(" ")
end

