
def is_prime?(num)
    return false if num < 2
    (2..num/2).none? {|i| num % i == 0}
end

def nth_prime(n)
    prime_counter = 0
    i = 1

    while prime_counter < n
        i += 1
        prime_counter += 1 if is_prime?(i)    
    end

    i
end


def prime_range(num_1, num_2)
    primes = []

    (num_1..num_2).each {|i| primes << i if is_prime?(i)}

    primes
end