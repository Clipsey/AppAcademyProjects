
require "byebug"

def element_count(array)
    counting_hash = Hash.new(0)
    array.each { |key| counting_hash[key] += 1 }
    counting_hash
end

def char_replace!(string, hash)
    string.each_char.with_index do |char, i|
        if hash.has_key?(char)
            string[i] = hash[char]
        end
    end
    string
end

def product_inject(array)
    debugger
    array.inject { |accu, val| accu * val }
end

