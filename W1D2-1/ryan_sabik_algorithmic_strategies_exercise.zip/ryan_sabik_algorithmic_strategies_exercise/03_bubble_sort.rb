# Reimplement the bubble sort outlined in the preceding lecture.
# The bubble_sort method should accept an array of numbers and arrange the elements in increasing order.
# The method should return the array.
# Do not use the built-in Array#sort

def bubble_sort(arr)
    #go through each index and compare to the next
    #if the current one is greater than the next, swap
    (0...arr.length-1).each do |idx|
        # every sweep through arr, the last position is correct
        # so only compare numbers that are not sorted; not in last position

        (0...arr.length-1-idx).each do |idx2|
            if arr[idx2] > arr[idx2 + 1]
              arr[idx2], arr[idx2 + 1] = arr[idx2 + 1], arr[idx2]
            end
        end
    end
    arr
end


p bubble_sort([2, 8, 5, 2, 6])      # => [2, 2, 5, 6, 8]
p bubble_sort([10, 8, 7, 1, 2, 3])  # => [1, 2, 3, 7, 8, 10]