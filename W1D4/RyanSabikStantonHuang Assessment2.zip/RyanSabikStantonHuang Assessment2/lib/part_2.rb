def proper_factors(num)
    result = []
    (1...num).each {|i| result << i if num % i == 0 }
    result
end

def aliquot_sum(num)
    proper_factors(num).sum
end

def perfect_number?(num)
    num == aliquot_sum(num)
end

def ideal_numbers(num)
    result = []
    i = 1
    while result.length < num
        result << i if perfect_number?(i)
        i += 1
    end
    result
end