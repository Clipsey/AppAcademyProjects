def my_reject(array, &prc)
    result = []
    array.each {|ele| result << ele if !prc.call(ele)}
    result
end

def my_one?(array, &prc)
#    found = false
#    array.each do |ele|
#        if found == false && prc.call(ele)
#            found = true
#        elsif found == true && prc.call(ele)
#            return false
#        end
#    end
#    found

    count = 0
    array.each {|ele| count += 1 if prc.call(ele)}
    count == 1
end

def hash_select(hash, &prc)
    result = Hash.new(0)
    hash.each {|k, v| result[k] = v if prc.call(k, v)}
    result
end

def xor_select(array, prc1, prc2)
    array.select {|ele| (prc1.call(ele) || prc2.call(ele)) && !(prc1.call(ele) && prc2.call(ele))}
end

def proc_count(value, proc_array)
    count = 0
    proc_array.each {|prc| count += 1 if prc.call(value)}
    count
end