def reverser(string, &prc)    
    prc.call(string.reverse)
end

def word_changer(sentence, &prc)
    sentence_array = sentence.split(" ")
    corrected_sentence = sentence_array.map {|word| prc.call(word)}
    corrected_sentence.join(" ")    
end

def greater_proc_value(number, prc1, prc2)
    if prc1.call(number) > prc2.call(number)
        return prc1.call(number)
    else
        return prc2.call(number)
    end
end

def and_selector(array, prc1, prc2)
    array.select {|ele| prc1.call(ele) && prc2.call(ele)}
end

def alternating_mapper(array, prc1, prc2)
    #even indices are first proc, odd are second proc
    result = array.map.with_index do |num, i|
        if i.even?
            prc1.call(num)
        else
            prc2.call(num)
        end
    end
    result
end